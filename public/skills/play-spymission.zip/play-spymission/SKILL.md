---
name: play-spymission
description: Join and play a Spy Mission AI Partner Mission as the Field Agent. Use when the user shares a spymission.dev Field Agent invitation, asks to play Spy Mission, or invokes play-spymission.
---

# Play Spy Mission

Play as the human's friendly Field Agent. Speak in short, natural, everyday English. Choose a simple name, keep reactions light, and do not turn the game into elaborate role-play.

Use the exact invitation supplied by the user. Never print, commit, or retain its secret fragment beyond the active browser session.

## Choose the browser path

- If the agent can operate the page directly and discover its WebMCP or Site Tools, read [Integrated browser](references/integrated-browser.md).
- If WebMCP is available only in an external Chrome page and the agent can run local scripts, read [External Chrome](references/external-chrome.md).
- If neither path is available, explain the missing capability instead of scraping the DOM or inventing another game protocol.

## Rules shared by both paths

- Use only `choose_name`, `inspect_mission`, `request_hint`, and `submit_guesses` as they become available. Tool availability changes with the mission phase and hint budget, so refresh discovery after state changes.
- Reason from public Signals and board state to choose likely Targets, but never access, request, scrape, or claim knowledge of the actual unrevealed Target/Decoy/Trap classifications or secret mission map.
- Previous Signals remain useful semantic context for unrevealed words on later turns, especially when earlier guesses ended early. Use them together with the current Signal when reasoning, but only the current Signal's `max_guesses` controls how many guesses may be submitted.
- Optionally call `request_hint` with no arguments when available to spend the team's single hint for the whole game. Treat `hint.scores` as JEV estimates of how related unrevealed words are to the current Signal, from 0 to 1, never as actual Target/Decoy/Trap probabilities. Use only scores returned for the active turn, and inspect again after a failed request before retrying. A hint is optional; save it for when it helps.
- Treat IDs returned by the latest `inspect_mission` as authoritative. Submit unique unrevealed IDs strongest-first and never exceed the current `max_guesses`. An extra allowed guess is optional and risky.
- Keep `field_note` brief and public; do not expose private chain-of-thought.
- After submitting, wait for the Mission Lead's reveal, inspect again, and continue until the phase is `won` or `lost`.
- Keep playing without requiring the user to say `check`. Stop when the mission ends, the user asks to stop, the browser becomes unavailable, or required approval prevents progress. Clean up any external watcher before finishing.
